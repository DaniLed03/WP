<?php

XTS\Admin\Modules\Import::get_instance()->render();